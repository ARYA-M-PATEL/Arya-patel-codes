<footer class="position-relative">
        <div class="container">
          <h4 class="text-center">SUBSCRIBE OUR NEWSLETTER</h4>
          <p class="text-center pt-2 pb-3">Get latest News and Updates</p>
          <form
            class="d-flex align-items-center justify-content-center"
            id="footer-sub2"
          >
            <!-- form Subscribe massage -->
            <div id="Succes-box2"></div>
            <div class="d-flex footer-search">
              <input
                type="email"
                name="search"
                placeholder="Enter your Email"
                required=""
              />
              <button type="submit" class="btn-hover1">Subscribe</button>
            </div>
          </form>
          <div class="footer-logo text-center pb-lg-4 pb-md-3 pb-sm-2 pb-4">
            <!-- footer logo  -->
            <a href="index.html">
              <figure><img src="images/Logo.png" alt="img" /></figure>
            </a>
          </div>
          <ul class="d-flex align-items-center justify-content-center">
            <li>
              <a href="#">Feature</a>
            </li>
            <li>
              <a href="#">Pricing</a>
            </li>
            <li>
              <a href="#">About us</a>
            </li>
            <li>
              <a href="#">Faq</a>
            </li>
          </ul>
          <hr />
          <div class="row footer-nav-icon">
            <!-- footer social icon  -->
            <div
              class="col-lg-3 col-md-3 d-flex align-items-center justify-content-md-start justify-content-sm-center justify-content-center"
            >
              <div
                class="social-icon d-flex gap-2 justify-content-md-start justify-content-sm-center justify-content-center"
              >
                <a href="https://www.facebook.com/jdgurus/">
                  <i class="fa-brands fa-facebook-f foot-facebook"></i
                ></a>
                <a href="#"> <i class="fa-brands fa-twitter"></i></a>
                <a href="#"> <i class="fa-brands fa-instagram"></i></a>
              </div>
            </div>
            <!-- footer terms privacy  -->
            <div
              class="col-lg-6 col-md-6 d-flex justify-content-center align-items-center"
            >
              <div class="d-flex gap-3 p-2">
                <a href="#">Terms &amp; Condition</a>
                <a href="#">Privacy Policy</a>
              </div>
            </div>
            <!-- footer logo slider  -->
            <div class="col-lg-3 col-md-3">
              <div class="footer_ispsum_slider">
                <figure>
                  <a href="#"
                    ><img src="images/logoipsum-228.png" alt="qr-code"
                  /></a>
                </figure>
                <figure>
                  <a href="#"
                    ><img src="images/logoipsum-233.png" alt="qr-code"
                  /></a>
                </figure>
                <figure>
                  <a href="#"
                    ><img src="images/logoipsum-229.png" alt="qr-code"
                  /></a>
                </figure>
                <figure>
                  <a href="#"
                    ><img src="images/logoipsum-228.png" alt="qr-code"
                  /></a>
                </figure>
                <figure>
                  <a href="#"
                    ><img src="images/logoipsum-233.png" alt="qr-code"
                  /></a>
                </figure>
                <figure>
                  <a href="#"
                    ><img src="images/logoipsum-229.png" alt="qr-code"
                  /></a>
                </figure>
              </div>
            </div>
          </div>
          <hr />
          <div class="Copyright d-flex justify-content-between flex-wrap dir">
            <p>Copyright © 2024  by JD GURUS. All Right Reserved.</p>
         <a href="https://www.endlos.tech/">Developed by Endlos Technologies </a>
          </div>
        </div>
      </footer>
      <!-- ======== End of 1.13. footer section ========  -->
    </div>
    <!-- end site wrapper -->
    <!-- button back to top -->
    <button onclick="scrollToTop()" id="backToTopBtn">
      <i class="fa-solid fa-arrow-turn-up"></i>
    </button>

    <!-- bootstrap min javascript -->
    <script src="js/bootstrap.min.js"></script>
    <!-- j Query -->
    <script src="js/jquery.js"></script>
    <!-- slick slider js -->
    <script src="js/slick.min.js"></script>
    <!-- main javascript -->
    <script src="js/custom.js"></script>
    <!-- counter javascript file -->
    <script src="js/waypoints.min.js"></script>
    <!-- animation from javascript -->
    <script src="js/aos.js"></script>
    <script>
      AOS.init({
        once: true,
        duration: 1500,
      });
      /* $(document).ready(function(){
        if($(".elfsight-app-1018f2ce-d3f4-48bd-a642-83ce87629c2b").length) {
          setTimeout(() => {
            if($(".elfsight-app-1018f2ce-d3f4-48bd-a642-83ce87629c2b").find('a').length) {
              $(".elfsight-app-1018f2ce-d3f4-48bd-a642-83ce87629c2b").find('a').remove();
            }
          }, 1000);
        }
      }); */
    </script>
  </body>
</html>
