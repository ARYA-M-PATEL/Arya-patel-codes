<?php include('includes/header.php'); ?>
<div class="container">
                <div class="contact-hero">
                    <h2 class="text-center">CONTACT</h2>
                    <P class="text-center">Reach out to us for unparalleled service and expert guidance.</P>
                </div>
            </div>
            <div class="map">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2966.428797486099!2d-88.05778112341208!3d41.9696025596794!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x880fac33cfefffff%3A0x2d667cd36067ee69!2sJD%20Gurus!5e0!3m2!1sen!2sin!4v1705988127519!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe> </div>
            <!-- ======== End of 5.1. contact-hero section ========  -->
        </div>
        <section class="d-flex justify-content-center">
            <div class="help position-relative">
            <div class="container">
                <div class="row d-flex gap-lg-5 gap-md-3 gap-sm-4 gap-3 justify-content-center">
                    <div class="col-lg-5 col-md-5 help-crd1" data-aos="fade-down"
                    data-aos-easing="linear"
                    data-aos-duration="1500">
                        <h4>HOW CAN WE HELP?</h4>
                        <P>Lorem ipsum dolor sit amet consectetur adipisicing elit. assumenda eligendi debitis sunt sequi tempora corporis, sed id animi eveniet.</P>
                        <div class="d-flex gap-4 align-items-center">
                            <i class="fa-solid fa-house"></i>
                            <span>6N381 Acacia Ln, Medinah, IL, United States, Illinois</span>
                        </div>
                        <div class="d-flex gap-4 align-items-center">
                            <i class="fa-solid fa-phone"></i>
                            <span>+1 630-523-9796</span>
                        </div>
                        <div class="d-flex gap-4 align-items-center">
                            <i class="fa-solid fa-envelope"></i>
                            <span>info@jdgurus.com</span>
                        </div>
                        <!-- <h5>OPERATING HOURS</h5>
                        <div class="d-flex gap-4 align-items-center">
                            <i class="fa-solid fa-clock"></i>
                            <span>Monday To Friday <br> 8:00am to 8:00pm AEDT</span>
                        </div> -->
                    </div>
                    <div class="col-lg-5 col-md-5 contact-email" data-aos="fade-down"
                    data-aos-easing="linear"
                    data-aos-duration="1500">
                        <h4>Book your free demo today</h4>
                        <form action="action_page.php"  id="footer-sub">  
                            <div class="row justify-content-center gap-3">
                                <input type="text" name="name" id="name" class="col-md-5 col-sm-12 col-12" placeholder="Your Name" required>
                                <input type="email" name="email" id="email" class="col-md-5 col-sm-12 col-12" placeholder="Email Address" required>
                                <input type="number" name="number" id="number" class="col-md-5 col-sm-12 col-12" placeholder="Phone Number" required>
                                <input type="text" name="Product" id="Product" class="col-md-5 col-sm-12 col-12" placeholder="Product" required>
                                <input type="text" name="IndustryType" id="IndustryType" class="col-md-5 col-sm-12 col-12" placeholder="Industry Type" required>
                                <input type="text" name="BusinessName" id="BusinessName" class="col-md-5 col-sm-12 col-12" placeholder="Business Name" required>
                                <textarea class="col-md-11 col-12" name="massage" id="massage" cols="30" rows="10" placeholder="Write here message"></textarea>
                            </div>
                            <div class="d-flex justify-content-center mt-4">
                                <button class=" e-btn btn-hover1" type="submit">Submit</button>
                            </div>
                        </form>
                    </div>
                    <div id="Succes-box"></div> 
                </div>
            </div>
            </div>
        </section>
         
        <!-- ======== 1.13. footer section ========  -->
        <?php include('includes/footer.php'); ?>