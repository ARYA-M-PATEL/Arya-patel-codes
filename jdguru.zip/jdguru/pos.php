<?php include('includes/header.php'); ?>
            <!-- ======== End of 1.1. header section ========  -->
            <!-- ======== 3.1. hero section ========  -->
            <section class="feature-hero"  data-aos="zoom-in">
                <div class="container">
                    <h1 class="text-center">FEATURES</h1>
                    <p class="text-center">The Complete POS Solution To Streamline Your Business Operations.</p>
                    <div class="position-relative">
                        <div class="featur-video">
                            <a class="video-play-button" href="#">
                                <span class="fa-solid fa-play"></span>
                            </a>

                        </div>
                        <figure class="feature-img"><img src="images/feature-girl.png" alt="POS System">
                        </figure>
                        <figure class="feature-img2"><img src="images/feature-rect.png" alt="Pos backgroung images">
                        </figure>
                    </div>
                </div>
            </section>
            <!-- ======== End of 3.1. hero section ========  -->
        </div>
        <!-- ======== 1.7. services section ========  -->
        <section class="services">
            <div class="container">
                <div class="row gap-md-0 gap-sm-4 gap-4">
                    <div class="col-lg-6 col-md-6" data-aos="fade-down">
                        <h2 class="text-lg-start text-md-start text-sm-center text-center">EXCEPTIONAL SERVICES AND
                            SOLUTIONS</h2>
                        <p
                            class="text-lg-start text-md-start text-sm-center text-center mt-lg-4 mt-md-2 mt-sm-2 mt-2 pb-4 ">
                            JD GURUS  Register is the easy-to-install, simple-to-use POS that transforms your business and makes your customers more valuable.</p>
                        <div class=" d-flex  justify-content-center gap-lg-4 gap-md-3 gap-sm-2 gap-2">
                            <div class="offers">
                                <h5 class="mb-2">Instant Transactions</h5>
                                <p class="p-f-s">Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                    Consequatur!</p>
                            </div>
                            <div class="offers">
                                <h5 class=" mb-2">Lower Cost</h5>
                                <p class="p-f-s">Make fewer errors and save on processing</p>
                            </div>
                        </div>
                        <div class=" d-flex  justify-content-center gap-lg-4 gap-md-3 gap-sm-2 gap-2 mt-2">
                            <div class="offers">
                                <h5 class="mb-2">Simplify Workflows</h5>
                                <p class="p-f-s">Take orders faster with a friendly system</p>
                            </div>
                            <div class="offers">
                                <h5 class=" mb-2">Grow Orders</h5>
                                <p class="p-f-s">Digitize customers and watch ticket sizes double</p>
                            </div>
                        </div>
                        <!-- <div
                            class="serives-btn justify-content-md-start justify-content-ms-center justify-content-center d-flex">
                            <a class="btn-hover1" href="#">Learn More</a>
                            <div class="d-flex align-items-center">
                                <a class="ps-4" href="#">Register Now </a>
                                <i class="fa-solid fa-greater-than ps-md-3 ps-sm-1 ps-0"></i>
                            </div>

                        </div> -->
                    </div>
                    <div class="col-lg-6 col-md-6 d-flex align-items-center justify-content-center sevices_img"
                        data-aos="fade-up">
                        <div class="position-relative">
                            <!-- <div class="social-rating"> -->
                                <!-- <div class="d-flex">
                                   <div class="d-flex">
                                        <span><i class="fa-brands fa-youtube"></i></span>
                                        <d>
                                            <h6>Youtube Premium</h6>
                                            <p>9 June 2023</p>
                                        </d iv>
                                    </div>
                                    <div class="d-flex text-pink">
                                        <p>-$</p>
                                        <p class="count">3.00</p>
                                    </div>
                                </div> -->
                                <!-- <div class="d-flex">
                                    <div class="d-flex">
                                        <span><i class="fa-brands fa-facebook"></i></span>
                                        <div>
                                            <h6>Facebook Ads</h6>
                                            <p>5 June 2023</p>
                                        </div>
                                    </div>
                                    <div class="d-flex text-green">
                                        <p>+$</p>
                                        <p class="count">21.00</p>
                                    </div>
                                </div> -->
                                <!-- <div class="d-flex">
                                    <div class="d-flex">
                                        <span><i class="fa-brands fa-pinterest-p"></i></span>
                                        <div>
                                            <h6>Pinterest</h6>
                                            <p>2 June 2023</p>
                                        </div>
                                    </div>
                                    <div class="d-flex text-pink">
                                        <p>-$</p>
                                        <p class="count">14.00</p>
                                    </div>
                                </div> -->
                                <!-- <div class="d-flex">
                                    <div class="d-flex">
                                        <span><i class="fa-brands fa-twitter"></i></span>
                                        <div>
                                            <h6>Twitter</h6>
                                            <p>1 June 2023</p>
                                        </div>

                                    </div>
                                    <div class="d-flex text-green">
                                        <p>+$</p>
                                        <p class="count">51.00</p>
                                    </div>
                                </div> -->
                            </div>
                            <figure><img src="images/pos.png" alt="sevice_img2"></figure>
                            <figure><img src="https://html-templates.evonicmedia.com/paypath/assets/images/icon/whitStar.png" alt="sevice_img3"></figure>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- ======== End of 1.7. services section ========  -->
        <!-- ======== 3.2. core section ========  -->
        <section class="core">
            <div class="container">
                <h2 class="text-center">CORE FEATURES</h2>
                <p class="core-p">Elevate your business with cutting-edge Point of Sale capabilities for streamlined operations</p>
                <div class="row d-flex gap-md-0 gap-sm-5 gap-5">
                    <div class="col-lg-4 col-md-4 d-flex flex-column gap-3 justify-content-center" data-aos="fade-up">
                        <div class="core-card">
                            <h5>Intuitive Interface</h5>
                            <p>Our products boast a user-friendly interface that empowers your staff to navigate transactions effortlessly. From processing sales to managing inventory, our sleek design ensures a seamless and efficient experience.</p>
                        </div>
                        <div class="core-card">
                            <h5>Multi-Platform Compatibility</h5>
                            <p>Access our systems on a variety of devices, from traditional cash registers to tablets and smartphones. With cloud-based synchronization, your data is always up-to-date, giving you the flexibility to manage your business from anywhere..</p>
                        </div>
                        <div class="core-card">
                            <h5>Inventory Management</h5>
                            <p>Say goodbye to manual inventory tracking headaches. JD Gurus can help your business automate your inventory management, provide real-time updates on stock levels, low inventory alerts, and insightful sales trends. Stay in control and optimize your stock to meet customer demand efficiently.</p>
                        </div>
                        <div class="core-card">
                            <h5>24/7 Customer Support</h5>
                            <p>Our dedicated support team is available around the clock to assist you. Whether you have questions about system functionality or need technical assistance, we're here to ensure your business operates smoothly..</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 d-flex justify-content-center align-items-center" data-aos="zoom-in">
                        <figure><img src="images/mobile.png" alt="img" class="moving"></figure>
                    </div>
                    <div class="col-lg-4 col-md-4 d-flex flex-column gap-3 justify-content-center" data-aos="fade-down">
                        <div class="core-card1">
                            <h5>Secure Transactions</h5>
                            <p>Trust is paramount in every transaction. JD Gurus prioritizes security, offering end-to-end encryption and compliance with industry standards. Rest easy knowing that your customers' sensitive information is protected, building trust and loyalty..</p>
                        </div>
                        <div class="core-card1">
                            <h5>Customizable Reporting</h5>
                            <p> Make data-driven decisions with our robust reporting tools. Our PoS solutions come prebuilt to generate customizable reports on sales, inventory turnover, and customer behavior, providing valuable insights to help you refine your business strategy.</p>
                        </div>
                        <div class="core-card1">
                            <h5>Customer Relationship Management (CRM)</h5>
                            <p>Elevate customer relationships with built-in CRM features. Keep track of customer preferences, purchase history, and loyalty program participation to deliver personalized experiences that keep them coming back.</p>
                        </div>
                        <div class="core-card1">
                            <h5>Seamless Integration</h5>
                          <p>JD Gurus can help your business seamlessly integrate with popular third-party applications and services. Connect your PoS system to accounting software, e-commerce platforms, and marketing tools, streamlining your business processes and maximizing efficiency.</p>                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- ======== End of 3.2. core section ========  -->
        <!-- ======== 1.8. visa section ========  -->
        <section class="gateway">
            <div class="container">
                <div class="row gap-lg-0 gap-md-0 gap-sm-4 gap-4">
                    <div class="col-lg-6 col-md-6 d-flex align-items-center justify-content-center" data-aos="fade-up">
                        <div class=" gateway-bg-img mt-5 ">
                            <figure><img src="images/cloud.png" alt="gate_img1" class="moving"></figure>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6  text-md-start text-sm-center text-center" data-aos="fade-down">
                        <h2>Mobile Cloud base Reporting</h2>
                        <p class="pt-lg-4 pt-md-3 pt-sm-2 pt-2 pb-2">Real-time, mobile access to what matters most in your business the data. Cash Register Express offers robust reporting that's highly customizable so you can focus on what's important and be empowered to make smarter business decisions.</p>
                        <div
                            class="gate mt-md-3 mt-sm-0 mt-4   d-flex flex-md-row flex-sm-column flex-column align-items-center">
                            <figure class="d-flex align-items-center"><img src="images/gate-icon1.png"
                                    alt="gate-img1"></figure>
                            <div class="ms-lg-3 ms-md-3 ms-sm-0 ms-0">
                                <h5 class="pb-2">Employees</h5>
                                <p class="p-f-s">Performance analysis Sales goal tracker Labor foreasts</p>
                            </div>
                        </div>
                        <div class="gate d-flex mt-4  flex-md-row flex-sm-column flex-column align-items-center">
                            <figure class="d-flex align-items-center"><img src="images/gate-icon2.png"
                                    alt="gate-img2"></figure>
                            <div class="ms-lg-3 ms-md-3 ms-sm-0 ms-0">
                                <h5 class="pb-2">Inventory</h5>
                                <p class="p-f-s">Low stock On hand products Product performance</p>
                            </div>
                        </div>
                        <div class="gate d-flex mt-4  flex-md-row flex-sm-column flex-column align-items-center">
                            <figure class="d-flex align-items-center"><img src="images/gate-icon3.png"
                                    alt="gate-img3"></figure>
                            <div class="ms-lg-3 ms-md-3 ms-sm-0 ms-0">
                                <h5 class="pb-2">Sales</h5>
                                <p class="p-f-s">Historical sales data Current sales and profits End of day reports</p>
                            </div>
                        </div>
                        <div class="gate-link text-lg-start text-md-start text-sm-center text-center">
                            <!-- <a class="btn-hover1" href="about.html">Get Started</a> -->
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- ======== End of 1.8. visa section ========  -->
        <!-- ======== 1.13. footer section ========  -->
        <?php include('includes/footer.php'); ?>