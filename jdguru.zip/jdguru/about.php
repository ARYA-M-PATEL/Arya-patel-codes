            
            <?php include('includes/header.php'); ?>
            <!-- ======== End of 1.1. header section ========  -->
            <!-- ======== 2.1. hero section ========  -->
            <section>
                <div class="about-hero container">
                    <h1 class="text-center">About Us</h1>
                    <p class="text-center about-p">Explore JD GURUS </p>
                    <div class="services  pb-lg-4 pb-md-2 pb-sm-0 pb-0 mb-lg-2 mb-md-1 mb-sm-0 mb-0">
                        <div class="container">
                            <div class="row gap-md-0 gap-sm-4 gap-4">
                                <div class="col-lg-6 col-md-6" data-aos="fade-up">
                                    <h2 class="text-lg-start text-md-start text-sm-center text-center">Reach all your business goals with the perfect tools from JD GURUS</h2>
                                    <p
                                      class="text-lg-start text-md-start text-sm-center text-center mt-lg-4 mt-md-2 mt-sm-2 mt-2 pb-4 ">
                                      We don’t stop at providing customers with the best in point of sale technology. We go beyond selling the best hardware, we also provide you with installation, training and continued support with your new system. That’s not all, 
                                        .</p>
                                    <p class="text-lg-start text-md-start text-sm-center text-center pb-4 ">
                                    we can also cover your equipment with 24/7 software and hardware support. Not many other companies can provide you with these services, but at JD GURUS it is our standard to provide you with all of the POS service and support you need. We have been doing it for over 18 years and we do it well…
                                        .</p>

                                    <!-- <div
                                        class="serives-btn justify-content-md-start justify-content-ms-center justify-content-center d-flex pt-lg-4 pt-md-2 pt-sm-2 pt-2">
                                        <a class="btn-hover1" href="#">Get The Card</a>

                                    </div> -->
                                </div>
                                <div class="col-lg-6 col-md-6 d-flex align-items-center justify-content-center abt" data-aos="fade-down">
                                    <div class="position-relative">
                                        <figure class="abut-hero-img1"><img src="images/lady-mobile.png" alt="img"></figure>
                                        <figure class="abut-hero-img2"><img src="images/star.png" alt="img"></figure>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- ======== 2.1. hero section ========  -->
        </div>
        <!-- ======== 1.4. finance section ========  -->
        <section class="finance mt-lg-4 mt-md-2 mt-sm-0 mt-0">
            <div class="container text-center">
              
                <div class="finanes-card row gap-md-0 gap-sm-4 gap-4">
                    <div class="col-lg-6 col-md-6 d-flex justify-content-center pe-lg-3 pe-md-0 pe-sm-3 pe-3">
                        <div class="fin-card" data-aos="flip-up">
                            <figure><img src="images/Vision.png" alt="praph"></figure>
                            <h4>Vision</h4>
                            <p class="p-f-s">"Our vision at JD GURUS is to be the unparalleled leader in providing end-to-end solutions for point of sale technology. We aspire to set the industry standard for innovation, reliability, and customer satisfaction. By continuously adapting to emerging trends, we aim to be the driving force behind businesses' success in an increasingly digital world."
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 d-flex justify-content-center pe-lg-3 pe-md-0 pe-sm-3 pe-3">
                        <div class="fin-card" data-aos="flip-up">
                            <figure> <img src="images/Mission.png" alt="doller"></figure>
                            <h4>Mission</h4>
                            <p class="p-f-s">At JD GURUS, our mission is to empower businesses with cutting-edge point of sale technology, delivering seamless integration, comprehensive training, and unwavering support. We strive to enhance operational efficiency and elevate customer experiences, ensuring our clients stay at the forefront of the ever-evolving retail landscape
                            </p>
                        </div>
                    </div>
                  
                </div>
            </div>
        </section>
        <!-- ======== End of 1.4. finance section ========  -->
        <!-- ======== 1.5. ispsum section ========  -->
        <div class="ispsum-logo">
            <div class="container">
                <hr>
                <div class="logo_ispsum_slider">
                    <a href="#">
                        <figure><img src="https://html-templates.evonicmedia.com/paypath/assets/images/icon/ipsum-1.png" alt="img"></figure>
                    </a>
                    <a href="#">
                        <figure><img src="https://html-templates.evonicmedia.com/paypath/assets/images/icon/ipsum-2.png" alt="img"></figure>
                    </a>
                    <a href="#">
                        <figure><img src="https://html-templates.evonicmedia.com/paypath/assets/images/icon/ispum-3.png" alt="img"></figure>
                    </a>
                    <a href="#">
                        <figure><img src="https://html-templates.evonicmedia.com/paypath/assets/images/icon/ipsum-4.png" alt="img"></figure>
                    </a>
                    <a href="#">
                        <figure><img src="https://html-templates.evonicmedia.com/paypath/assets/images/icon/ipsum-1.png" alt="img"></figure>
                    </a>
                    <a href="#">
                        <figure><img src="https://html-templates.evonicmedia.com/paypath/assets/images/icon/ipsum-2.png" alt="img"></figure>
                    </a>
                    <a href="#">
                        <figure><img src="https://html-templates.evonicmedia.com/paypath/assets/images/icon/ispum-3.png" alt="img"></figure>
                    </a>
                    <a href="#">
                        <figure><img src="https://html-templates.evonicmedia.com/paypath/assets/images/icon/ipsum-4.png" alt="img"></figure>
                    </a>
                </div>
                <hr>
            </div>
        </div>
        <!-- ======== End of 1.5. ispsum section ========  -->
        <!-- ======== 2.2. banner section ========  -->
        <section>
            <div class="container about-banner" data-aos="zoom-in">
                <div class="d-flex justify-content-lg-end justify-content-md-end justify-content-ms-center justify-content-center">
                    <div class="banner-text">
                        <h3 class="text-md-start text-sm-center text-center">24/7 Support On JD GURUS <br>  Point Of Sale Systems
                        </h3>
                        <p class="text-md-start text-sm-center text-center p-f-s">Support on all of our systems when you need it and local technicians on stand by to get you back up and running. Our technicians are experienced in providing the fastest solutions to any problems you are having with your system.</p>
                        <div class="visa-btn text-sm-center text-md-start text-center">
                          
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- ========End of 2.2. banner section ========  -->
        <!-- ======== 1.6. gateway section ========  -->
       
        <!-- ======== End of 1.6. gateway section ========  -->
        <!-- ======== 2.3. round-word section ========  -->
        <section class="round-word">
            <div class="container">
                <div class="row gap-lg-0 gap-md-0 gap-sm-4 gap-4">
                    <div class="col-lg-6 col-md-6 d-flex align-items-lg-start align-items-md-start align-items-ms-center align-items-center justify-content-center flex-column" data-aos="fade-up">
                        <h2 class="text-lg-start text-md-start text-sm-center text-center">WE ARE ROUND THE USA</h2>
                        <P class="text-lg-start text-md-start text-sm-center text-center">JD GURUS extends its expertise nationwide, providing cutting-edge point of sale solutions, reliable hardware, and unparalleled support. From coast to coast, we are your trusted partner in revolutionizing retail technology..</P>
                            <div class="d-flex gap-3">
                                <div class="sticker">
                                    <div class="d-flex">
                                        <h3 class="count">2500</h3>
                                        <!-- <h3>K+</h3> -->
                                    </div> <span>clients</span>
                                </div>
                                <div class="sticker st-bg">
                                    <div class="d-flex">
                                        <h3 class="count">25</h3>
                                 
                                    </div> <span>states</span>
                                </div>
                            </div>
                        <div class="d-flex gap-3">
                            <div class="sticker st-bg">
                                <div class="d-flex">
                                    <h3 class="count">90</h3>
                                    <h3>%</h3>
                                </div> <span>Satisfied user</span>
                            </div>
                            <div class="sticker">
                                <div class="d-flex">
                                    <h3 class="count">200</h3>
                                    <h3>+</h3>
                                </div> <span>Partners Joined</span>
                            </div>
                        </div>
                      
                    </div>
                    <div class="col-lg-6 col-md-6 d-flex align-items-center justify-content-center" data-aos="fade-down">
                        <figure><img src="images//round-word.jpg" alt="img"></figure>
                    </div>
                </div>
            </div>
        </section>
        <!-- ========End of 2.3. round-word section ========  -->
        <!-- ======== 2.4. behind section ========  -->
        <section class="behind b-back">
            <div class="container">
                <h2 class="text-center">HOW'S BEHIND</h2>
                <p class="b-para">Behind JD Gurus' exceptional point of sale technology is over 18 years of dedicated service, providing not just cutting-edge hardware, but also comprehensive installation, training, and 24/7 software and hardware support for an unmatched POS experience.</p>
                <div class="row gap-md-0 gap-sm-4 gap-4 mt-3">
                    <div class="col-lg-6 col-md-6 d-flex"  data-aos="flip-up">
                        <div><img src="images/behind2.jpg" alt="img">director image</div>
                        <div class="ps-4">
                            <h4>Jatin Patel</h4>
                            <p>President at JD Gurus Inc</p>
                            <div class="b-icon">
                                <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
                                <a href="#"><i class="fa-brands fa-whatsapp"></i></a>
                                <a href="#"><i class="fa-brands fa-instagram"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 d-flex"  data-aos="flip-up">
                        <div>
                            <figure><img src="https://html-templates.evonicmedia.com/paypath/assets/images/about/behind.jpg" alt="img"></figure>
                        </div>
                        <div class="ps-4">
                            <h4>Emma White</h4>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab dolore voluptate aut?</p>
                            <div class="b-icon">
                                <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
                                <a href="#"><i class="fa-brands fa-whatsapp"></i></a>
                                <a href="#"><i class="fa-brands fa-instagram"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- ======== End of 2.4. behind section ========  -->
        <!-- ======== 1.10. profaessional section ========  -->
        <section class="profaessional mt-lg-5 mt-md-3 mt-sm-3 mt-3">
            <div class="container">
                <h2 class="text-center">Trusted By Professionals</h2>
                <P class="text-center pt-3 pb-5 mb-2">Dive into the success stories of those who entrusted JD Gurus for their point of sale needs. Discover firsthand the seamless integration, unparalleled support, and transformative impact that define our client testimonials</P>
                <div class="prof-size" data-aos="zoom-in-up">
                    <div class="prof-slider ">
                        <div class="prof-slide position-relative">
                            <div>
                                <div class="d-flex  align-items-center justify-content-center">
                                    <!-- <img src="https://html-templates.evonicmedia.com/paypath/assets/images/slider/profational2.png" alt="img" class="prof-img-2"> -->
                                </div>
                                <div>
                                    <img src="images/Comma.png" alt="img" class="prof-img-1">
                                </div>
                                <p class="text-center p-f-s">The job was nicely done in a timely manner with expectations being met. I thought I would have to learn a lot since they changed the system entirely, but it was actually a very easy and almost same process.</p>
                                <div class="prof-star pt-2 pb-2 text-center">
                                    <span class="stars text-lg-start">
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                    </span>
                                </div>
                                <h5 class="text-center">Salvador Zermeno</h5>
                                <p class="text-center pt-2 pb-5 p-f-s">Owner, Lindy's and Gertie's of Bridgeview</p>
                            </div>
                        </div>
                        <div class="prof-slide position-relative">
                            <div>
                                <div class="d-flex  align-items-center justify-content-center">
                                    <!-- <img src="https://html-templates.evonicmedia.com/paypath/assets/images/slider/profactional3.png" alt="img" class="prof-img-2"> -->
                                </div>
                                <div>
                                <img src="images/Comma.png" alt="img" class="prof-img-1">
                                </div>
                                <p class="text-center p-f-s">We are with JD Gurus Since 6 years. They provide best customer services. They are very helpful for Scandata Program.  We recommend JD Gurus Inc for ATM Service, POS and Credit Card Services and Internet also.</p>
                                <div class="prof-star pt-2 pb-2 text-center">
                                    <span class="stars text-lg-start">
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                    </span>
                                </div>
                                <h5 class="text-center">Denison Food Mart</h5>
                                <p class="text-center pt-2 pb-5 p-f-s">Shop Owner</p>
                            </div>
                        </div>
                        <div class="prof-slide position-relative">
                            <div>
                                <div class="d-flex  align-items-center justify-content-center">
                                    <!-- <img src="https://html-templates.evonicmedia.com/paypath/assets/images/slider/profacitional.png" alt="img" class="prof-img-2"> -->
                                </div>
                                <div>
                                <img src="images/Comma.png" alt="img" class="prof-img-1">
                                </div>
                                <p class="text-center p-f-s">Best POS Systems . 24 * 7 technical support and service . very friendly peoples. very professional . I recommend them !</p>
                                <div class="prof-star pt-2 pb-2 text-center">
                                    <span class="stars text-lg-start">
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                    </span>
                                </div>
                                <h5 class="text-center">Armitage Wine</h5>
                                <p class="text-center pt-2 pb-5 p-f-s">Pioneer Liquor</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- ======== End of 1.10. profaessional section ========  -->
        <!-- ======== 1.13. footer section ========  -->
        <?php include('includes/footer.php'); ?>