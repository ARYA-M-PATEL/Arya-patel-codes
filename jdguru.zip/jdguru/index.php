<?php include('includes/header.php'); ?>
       <!-- ======== 1.2. hero section ======== -->
       <section class="hero">
                <div class="container">
                    <div class="row text-md-start text-sm-center text-center gap-md-0 gap-sm-4 gap-5">
                        <div data-aos="fade-up" class="col-md-6 d-flex align-items-md-start align-items-ms-center align-items-center justify-content-center flex-column">
                            <h1>Easy-to-use Point of Sale</h1>
                            <p>You may start selling in a matter of minutes and easy to use. Appropriate for all devices.</p>
                            <a class="btn-hover1" href="about.html">Get the Card</a>
                        </div>
                        <div data-aos="fade-down" class="col-md-6 position-relative d-flex flex-column justify-content-center align-items-center mt-md-0 mt-sm-5 mt-4">
                            <img src="images/hero.png" alt="hero_img1" class="moving">
                            <img src="images/hero_watch.png" alt="hero_img2">
                            <img src="images/hero_star.png" alt="hero_icon">
                        </div>
                    </div>
                </div>
            </section>
            <!-- ======== End of 1.2. hero section ========  -->
            <!-- ======== 1.3. about section ========  -->
            <section class="about">
                <div class="container">
                    <div class="row text-md-start text-sm-center text-center">
                        <div class="col-md-4 d-flex justify-content-between">
                            <div class="ab_card1" data-aos="flip-left">
                                <h3>About</h3>
                                <p class="p-f-s">Founded in 2006, JD Gurus set out to provide comprehensive technical solutions for our retail and restaurant clients. Starting from a bedroom, the company has grown to support over 2500 clients across 25 states. Our guiding principles—Simple, Reliable, Affordable—underscore our commitment to delivering excellent services.</p>
                                <div class="d-flex align-items-center justify-content-lg-start justify-content-md-center justify-content-center">
                                    <a class="btn-hover1" href="about.html">Learn More</a>
                                    <div class="abut-video">
                                        <a class="video-play-button" href="https://www.youtube.com/">
                                        <span class="fa-solid fa-play"></span>
                                        </a>
            
                                    </div>
                                    <div class="p-f-s w-v">Watch Video</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8 d-flex justify-content-center mt-md-0 mt-sm-3 mt-3">
                            <div class="ab_card2 d-flex flex-column justify-content-between" data-aos="flip-right">
                                <div>
                                    <div class="row gap-md-0 gap-sm-3 gap-3">
                                        <div class="col-md-5 col-sm-12 col-12 ">
                                            <div class="d-flex justify-content-md-start justify-content-sm-center justify-content-center">
                                                <h3 class="text">Simple</h3>
                                              
                                            </div>
                                            <p class="p-f-s">Simplicity is key for us. In the fast-paced world of technology, we want our clients to relax, not stress about keeping up. Count on us to provide you with the latest and easiest-to-use technology, simplifying your life effortlessly.</p>
                                        </div>
                                        <div class="col-2 p-0 d-flex justify-content-center align-items-center">
                                            <hr>
                                        </div>
                                        <div class="col-md-5 col-sm-12 col-12 p-0">
                                        <h3 class="text">Reliable</h3>
                                            <p class="p-f-s">With nearly two decades of experience, our seasoned team of experts is committed to surpassing your expectations. We are dedicated to preventing any disruptions to your operations, ensuring that our systems keep you seamlessly moving forward without downtime. Your satisfaction is not just our goal—it's our standard.


                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="d-flex mb-3 mt-4 gap-4 justify-content-md-start justify-content-ms-center justify-content-center">
                                    <div class="position-relative">
                                    <h3 class="text">Affordable</h3>
                                            <p class="p-f-s">In the grand scheme of things, the bottom line is crucial. We take pride in providing high-quality, user-friendly products that are not only cost-effective but also dependable. Our diverse range of packages accommodates every budget, ensuring you can enhance your business without any compromises.


                                            </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <!-- ======== End of 1.3. about section ========  -->
        <!-- ======== 1.4. finance section ========  -->
        <section class="finance">
            <div class="container text-center">
                <h2>Driving All of Your Business Operations</h2>
                <p class="mt-0">Empower your business with our comprehensive solutions that drive seamless operations, from Point-of-Sale excellence to efficient CCTV integration. Elevate every aspect of your business with our tailored services.</p>
                <div class="finanes-card row gap-md-0 gap-sm-4 gap-4">
                    <div class="col-lg-4 col-md-4 d-flex justify-content-center pe-lg-3 pe-md-0 pe-sm-3 pe-3">
                        <div class="fin-card" data-aos="flip-up">
                            <figure><img src="images/graphe.png" alt="praph"></figure>
                            <h4>POS</h4>
                            <p class="p-f-s">  Whether you run a bustling retail store, a trendy cafe, or a growing service-oriented business, JD Gurus can help you design a system to streamline your operations, enhance customer experiences, and boost your bottom line.
                            </p>
                            <a class="btn-hover1" href="pos.php">Explore Features</a>
                        </div>
                      
                    </div>
                    <div class="col-lg-4 col-md-4 d-flex justify-content-center pe-lg-3 pe-md-0 pe-sm-3 pe-3">
                        <div class="fin-card" data-aos="flip-up">
                            <figure> <img src="images/doller.png" alt="doller"></figure>
                            <h4>CCTV</h4>
                            <p class="p-f-s">
                           In a world where safety is paramount, our state-of-the-art CCTV system is meticulously crafted to offer unparalleled protection for your home or business. Immerse yourself in the peace of mind that comes with advanced surveillance technology,
                            </p>
                            <a class="btn-hover1" href="cctv.php">Explore Features</a>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 d-flex justify-content-center">
                        <div class="fin-card" data-aos="flip-up">
                            <figure><img src="images/arow.png" alt="arow"></figure>
                            <h4>Merchant Services</h4>
                            <p class="p-f-s">In a world where seamless transactions and efficient payment processing are paramount, JD Gurus is your gateway to unparalleled reliability, innovation, and customer satisfaction..
                            </p>
                            <a class="btn-hover1" href="merchantservices.php">Explore Features</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- ======== End of 1.4. finance section ========  -->
        <!-- ======== 1.5. ispsum section ========  -->
        <div class="ispsum-logo">
            <div class="container">
                <hr>
                <div class="logo_ispsum_slider">
                    <a href="#">
                        <figure><img src="images/ipsum-1.png" alt="img"></figure>
                    </a>
                    <a href="#">
                        <figure><img src="images/ipsum-2.png" alt="img"></figure>
                    </a>
                    <a href="#">
                        <figure><img src="images/ispum-3.png" alt="img"></figure>
                    </a>
                    <a href="#">
                        <figure><img src="images/ipsum-4.png" alt="img"></figure>
                    </a>
                    <a href="#">
                        <figure><img src="images/ipsum-1.png" alt="img"></figure>
                    </a>
                    <a href="#">
                        <figure><img src="images/ipsum-2.png" alt="img"></figure>
                    </a>
                    <a href="#">
                        <figure><img src="images/ispum-3.png" alt="img"></figure>
                    </a>
                    <a href="#">
                        <figure><img src="images/ipsum-4.png" alt="img"></figure>
                    </a>
                </div>
                <hr>
            </div>
        </div>
        <!-- ======== End of 1.5. ispsum section ========  -->
        <!-- ======== 1.6. gateway section ========  -->
        <!-- <section class="gateway">
            <div class="container">
                <div class="row gap-lg-0 gap-md-0 gap-sm-4 gap-4">
                    <div class="col-lg-6 col-md-6 d-flex align-items-center justify-content-center" data-aos="fade-up">
                        <div class=" gateway-bg-img mt-5 ">
                            <figure><img src="images/gateway-1.png" alt="gate_img1" class="moving"></figure>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6  text-md-start text-sm-center text-center" data-aos="fade-down">
                        <h2>Best solution for point of sale about details</h2>
                        <p class="pt-lg-4 pt-md-3 pt-sm-2 pt-2 pb-2">Lorem ipsum dolor sit amet consectetur adipisicing
                            elit.
                            Perferendis iure eius autem
                            beatae
                            mollitia quasi, neque magni excepturi velit ullam sunt eos minima.</p>
                        <div class="gate mt-md-3 mt-sm-0 mt-4   d-flex flex-md-row flex-sm-column flex-column align-items-center">
                            <figure class="d-flex align-items-center"><img src="images/gate-icon1.png" alt="gate-img1"></figure>
                            <div class="ms-lg-3 ms-md-3 ms-sm-0 ms-0">
                                <h5 class="pb-2">Other point of sale information</h5>
                                <p class="p-f-s">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quia illum
                                    corporis
                                    voluptatibus nihil? Facilis, sunt.</p>
                            </div>
                        </div>
                        <div class="gate d-flex mt-4  flex-md-row flex-sm-column flex-column align-items-center">
                            <figure class="d-flex align-items-center"><img src="images/gate-icon2.png" alt="gate-img2"></figure>
                            <div class="ms-lg-3 ms-md-3 ms-sm-0 ms-0">
                                <h5 class="pb-2">Best process system POS</h5>
                                <p class="p-f-s">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quia illum
                                    corporis
                                    voluptatibus nihil? Facilis, sunt.</p>
                            </div>
                        </div>
                        <div class="gate d-flex mt-4  flex-md-row flex-sm-column flex-column align-items-center">
                            <figure class="d-flex align-items-center"><img src="images/gate-icon3.png" alt="gate-img3"></figure>
                            <div class="ms-lg-3 ms-md-3 ms-sm-0 ms-0">
                                <h5 class="pb-2">Enjoy Full Access</h5>
                                <p class="p-f-s">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quia illum
                                    corporis
                                    voluptatibus nihil? Facilis, sunt.</p>
                            </div>
                        </div>
                        <div class="gate-link text-lg-start text-md-start text-sm-center text-center">
                            <a class="btn-hover1" href="about.html">Get Started</a>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
        <!-- ======== End of 1.6. gateway section ========  -->
        <!-- ======== 1.7. services section ========  -->
        <section class="services">
            <div class="container">
                <div class="row gap-md-0 gap-sm-4 gap-4">
                    <div class="col-lg-12 col-md-12" data-aos="fade-down">
                        <h2 class="text-lg-start text-md-start text-sm-center text-center">Perfect POS software for most retail stores</h2>
                    
                        <div class=" d-flex  justify-content-center gap-lg-4 gap-md-3 gap-sm-2 gap-2 mt-4">
                            <div class="offers">
                                <h5 class="mb-2">Retail</h5>
                                <!-- <p class="p-f-s">Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                    Consequatur!</p> -->
                            </div>
                            <div class="offers">
                                <h5 class=" mb-2"> Liquor Store</h5>
                                <!-- <p class="p-f-s">Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                    Consequatur!</p> -->
                            </div>
                            <div class="offers">
                                <h5 class=" mb-2">Convenience Store</h5>
                                <!-- <p class="p-f-s">Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                    Consequatur!</p> -->
                            </div>
                            <div class="offers">
                                <h5 class="mb-2">Dollar Storen</h5>
                                <!-- <p class="p-f-s">Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                    Consequatur!</p> -->
                            </div>
                            <div class="offers">
                                <h5 class=" mb-2">Bar</h5>
                                <!-- <p class="p-f-s">Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                    Consequatur!</p> -->
                            </div>
                            <div class="offers">
                                <h5 class=" mb-2">Restaurant</h5>
                                <!-- <p class="p-f-s">Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                    Consequatur!</p> -->
                            </div>
                        </div>
                    
                        <div class=" d-flex  justify-content-center gap-lg-4 gap-md-3 gap-sm-2 gap-2 mt-2">
                            <div class="offers">
                                <h5 class="mb-2">Jewelry Store</h5>
                                <!-- <p class="p-f-s">Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                    Consequatur!</p> -->
                            </div>
                            <div class="offers">
                                <h5 class=" mb-2">Salon</h5>
                                <!-- <p class="p-f-s">Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                    Consequatur!</p> -->
                            </div>
                            <div class="offers">
                                <h5 class=" mb-2"> e-commerce</h5>
                                <!-- <p class="p-f-s">Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                    Consequatur!</p> -->
                            </div>
                       
                            <div class="offers">
                                <h5 class="mb-2">Hospitality</h5>
                                <!-- <p class="p-f-s">Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                    Consequatur!</p> -->
                            </div>
                            <div class="offers">
                                <h5 class=" mb-2">Super Markets</h5>
                                <!-- <p class="p-f-s">Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                    Consequatur!</p> -->
                            </div>
                            <div class="offers">
                                <h5 class=" mb-2">Wholesale Markets</h5>
                                <!-- <p class="p-f-s">Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                    Consequatur!</p> -->
                            </div>
                        </div>
                  ]
                    </div>
                </div>
            </div>
        </section>
        <!-- ======== End of 1.7. services section ========  -->
        <!-- ======== 1.8. visa section ========  -->
        <section class="visa">
            <div class="container">
                <div class="visa-bg" data-aos="zoom-in">
                    <figure><img src="images/vesa-back.png" alt="visa-img"></figure>
                </div>
                <div class="visa-contant" data-aos="fade-up">
                    <div class="row">
                        <div class="col-lg-6 col-md-6">
                            <h3 class="text-md-start text-sm-center text-center"> Discover the Ultimate Point of Sale Software for Any Store
                            </h3>
                            <p class="text-md-start text-sm-center text-center p-f-s">Join the ranks of satisfied businesses nationwide with our unparalleled services. Trusted by 2500 clients spanning 25 states, our solutions redefine excellence, ensuring seamless operations and success for your business. Elevate your venture with a proven partner in innovation and reliability..</p>
                            <!-- <p class="text-md-start text-sm-center text-center p-f-s">Lorem ipsum dolor sit amet
                                consectetur
                                adipisicing elit. Nam aut explicabo at qui laudantium.</p> -->
                            <div class="visa-btn text-sm-center text-md-start text-center">
                                <!-- <a class="btn-hover1" href="#">Try PayPath Now</a> -->
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                        
                            <div class="d-flex pt-2 justify-content-md-start justify-content-center justify-content-center">
                                <h2 class="count">2500</h2>
                                <h2>+</h2>
                                <h6 class="d-flex align-items-center ps-2 ">clients </h6>
                            </div>
                            <div class="d-flex pt-2 justify-content-md-start justify-content-center justify-content-center">
                                <h2 class="count">25</h2>
                               
                                <h6 class="d-flex align-items-center ps-2 ">states </h6>
                            </div>
                            
                            <div class="visa-card position-relative mt-3">
                                <img src="images/Card.png" alt="visa-card">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- ======== End of 1.8. visa section ========  -->
        <!-- ========  1.9. pricing section ========  -->
        <!-- <section class="pricing pricing-b-g">
            <div class="container">
                <div class="row ">
                    <div class="col-lg-6 col-md-6 d-flex align-items-center justify-content-center pricing-bg" data-aos="fade-up">
                        <div>
                            <figure><img src="images/pricinge.png" alt="pric-img1" class="moving"></figure>
                            <figure><img src="images/hero_star.png" alt="pric-img2"></figure>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 mt-md-0 mt-sm-5 mt-5" data-aos="fade-down">
                        <h2 class=" text-md-start text-sm-center text-center">ECONOMICAL PRICING OPTIONS</h2>
                        <p class="text-md-start text-sm-center text-center p-md-0 p-sm-2 p-2">Lorem ipsum, dolor sit amet consectetur
                            adipisicing elit. Incidunt excepturi enim vero soluta veritatis quis reprehenderit.
                            Incidunt
                            excepturi enim vero soluta veritatis quis reprehenderit.</p>
                        <div class="pric-list">
                            <h6>Personal</h6>
                            <div class="d-flex">
                                <div class="mt-3 me-3"><i class="fa-solid fa-check"></i></div>

                                <div class="d-flex justify-content-between gap-1">
                                    <p class="p-f-s">Lorem ipsum dolor sit amet, consectetur adipiset quatit. Dolorem,
                                        quia?</p>
                                    <div class="d-flex pric-sup">
                                        <h2>$</h2>
                                        <h2>1.54</h2>
                                        <p>/month</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="pric-list second">
                            <h6>Business</h6>
                            <div class="d-flex justify-content-between">
                                <div class="mt-3 me-3"><i class="fa-solid fa-check"></i></div>
                                <div class="d-flex justify-content-between">
                                    <p class="p-f-s">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorem,
                                        quia?</p>
                                    <div class="d-flex pric-sup ">
                                        <h2>$</h2>
                                        <h2>4.54</h2>
                                        <p>/month</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="text-md-start text-sm-center text-center pt-lg-4 pt-md-2 pt-sm-0 pt-1">
                            <a class="btn-hover1" href="#">Get Started</a>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
        <!-- ======== End of 1.9. pricing section ========  -->
        <!-- ======== 1.10. profaessional section ========  -->
        
        <!-- ======== End of 1.10. profaessional section ========  -->
        <!-- ======== 1.11. question section ========  -->
        <section class="question">
            <div class="container">
                <div class="row">
                    <div class="question-text col-lg-6 col-md-6 tab-center" data-aos="fade-up">
                        <h2 class="text-lg-start text-md-start text-sm-center text-center">FREQUENTLY ASKED
                            QUESTIONS
                        </h2>
                        <p class="text-lg-start text-md-start text-sm-center text-center mt-md-3 mt-3">Lorem ipsum dolor
                            sit amet
                            consectetur, adipisicing elit. Dolorem deleniti harum sint porro
                            atque!.ipsum dolor sit amet consectetur, adipisicing elit. Dolorem deleniti harum sint
                            porro
                            atque!</p>
                        <div class="text-lg-start text-md-start text-sm-center text-center ">
                            <a class="btn-hover1" href="faq.html">More FAQs</a>
                        </div>
                    </div>
                    <div class="question-collapes col-lg-6 col-md-6 mt-md-0 mt-sm-3 mt-3" data-aos="zoom-in">
                        <div class="accordion" id="accordionExample">
                            <div class="accordion-item">
                                <h5 class="accordion-header" id="headingOne">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                      How does microfinancing work?
                                    </button>
                                </h5>
                                <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p> Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquam possimus
                                            minima, saepe praesentium expedita non error. Consectetur tempore maxime
                                            repudiandae deleniti animi omnis inventore aspernatur, exercitationem
                                            voluptas
                                            qui veniam maiores.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h5 class="accordion-header" id="headingTwo">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                         What types of businesses are eligible for this service?
                                    </button>
                                </h5>
                                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Velit perferendis
                                            quibusdam tempore. A vel maxime obcaecati aperiam omnis deserunt mollitia
                                            commodi, modi dolorem eos dicta, iusto sunt ipsa sequi laborum!</p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h5 class="accordion-header" id="headingThree">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                        How long does it take to receive funds?
                                    </button>
                                </h5>
                                <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p> Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid natus ullam
                                            ab
                                            consequuntur assumenda nisi quibusdam exercitationem qui similique ducimus
                                            molestias iusto facere quidem ratione, pariatur repudiandae! Vitae, quia
                                            doloremque?</p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h5 class="accordion-header" id="headingFour">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                         How can I contact with support?
                                    </button>
                                </h5>
                                <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium
                                            molestias
                                            illo quisquam esse. Sapiente animi est sint ex? Vero voluptatum voluptatem
                                            natus
                                            pariatur harum maiores eos possimus consectetur repellat quidem?</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- <section>
        <script src="https://static.elfsight.com/platform/platform.js" data-use-service-core defer></script>
        <div class="elfsight-app-1018f2ce-d3f4-48bd-a642-83ce87629c2b" data-elfsight-app-lazy></div>
        </section> -->

    
        <!-- ======== End of 1.11. question section ========  -->
        <!-- ======== 1.12. news-cards section ========  -->
        <section class="news-cards">
            <div class="container">
                <h2 class="text-center">OUR LATEST NEWS &amp; EVENTS</h2>
                <p class="text-center news-p">Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestiae eum
                    vitae voluptatibus ad laudantium culpa consequatur aperiam nulla.</p>
                <div class="row d-flex gap-md-0 gap-sm-5 gap-4">
                    <div class="col-lg-4 col-md-4 d-flex" data-aos="flip-right">
                        <div class="card news-card-back">
                            <img src="images/news-1.png" alt="card-img">
                            <div class="card-body">
                                <a href="#">
                                    <h5>Choosing a Payment Gateway: Key Factors to Consider</h5>
                                </a>
                                <p class="card-text p-f-s">Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                                    Voluptates magni veniam officia?.</p>
                            </div>
                            <hr class="dotted-line">
                            <div class="card-viewer d-flex justify-content-between ">
                                <div>
                                    <i class="fa-solid fa-calendar-days"></i>
                                    <span>2023/06/12</span>
                                </div>
                                <div>
                                    <i class="fa-regular fa-message"></i>
                                    <span>0</span>
                                </div>
                            </div>
                            <div class="news-link">
                                <a class="btn-hover1" href="#">Read More</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 d-flex" data-aos="flip-right">
                        <div class="card news-card-back">
                            <img src="images/news-2.png" alt="image">
                            <div class="card-body">
                                <a href="#">
                                    <h5>Top Strategies to do Successful Online Business</h5>
                                </a>
                                <p class="card-text p-f-s">Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                    Molestias aperiam doloribus totam.</p>
                            </div>
                            <hr class="dotted-line">
                            <div class="card-viewer d-flex justify-content-between ">
                                <div>
                                    <i class="fa-solid fa-calendar-days"></i>
                                    <span>2023/06/12</span>
                                </div>
                                <div>
                                    <i class="fa-regular fa-message"></i>
                                    <span>0</span>
                                </div>
                            </div>
                            <div class="card-color">
                                <a class="btn-hover1" href="#">Read More</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 d-flex" data-aos="flip-right">
                        <div class="card news-card-back">
                            <img src="images/news-3.png" alt="image">
                            <div class="card-body">
                                <a href="#">
                                    <h5>The Benefits of Microfinancing for Small Business</h5>
                                </a>
                                <p class="card-text p-f-s">Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                    Tenetur, error impedit.</p>
                            </div>
                            <hr class="dotted-line">
                            <div class="card-viewer d-flex justify-content-between ">
                                <div>

                                    <i class="fa-solid fa-calendar-days"></i>
                                    <span>2023/06/12</span>
                                </div>
                                <div>
                                    <i class="fa-regular fa-message"></i>
                                    <span>0</span>
                                </div>
                            </div>
                            <div>
                                <a class="btn-hover1" href="#">Read More</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- ======== End of 1.12. news-cards section ========  -->
              <?php include('includes/footer.php'); ?>
